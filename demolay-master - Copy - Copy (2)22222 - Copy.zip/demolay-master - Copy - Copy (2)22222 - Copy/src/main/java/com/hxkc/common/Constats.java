package com.hxkc.common;

public interface Constats {
	
	public static final String CURRENTUSER = "_currentUser";
	
	public static final String RESOURCECACHENAME = "resourceCache";

}
