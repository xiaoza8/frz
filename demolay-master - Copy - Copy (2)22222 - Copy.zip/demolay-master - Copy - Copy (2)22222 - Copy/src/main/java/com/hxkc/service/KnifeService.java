package com.hxkc.service;


//import com.github.pagehelper.PageInfo;
//import com.lea.proj.model.Cost;
//import com.lea.proj.model.common.Select2Vo;

import com.hxkc.entity.Knife;
import com.hxkc.entity.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import java.util.List;

public interface KnifeService {

//    PageInfo<Cost> getDataByPage(Integer pageNum, Integer pageSize);
//
  void importExcel(List<Knife> costList);

  /**
   * 关键字分页
   * @param searchText
   * @param pageRequest
   * @return
   */
  Page<Knife> findAllByLike(String searchText, PageRequest pageRequest);
//
//    List<Select2Vo> getAllOrderId();
//
//    List<Cost> getAll();
//
//    PageInfo<Cost> selectByConditions(Integer pageNum, Integer pageSize, Long id, String startTime, String endTime, String startTime1, String endTime1);
}
