package com.hxkc.service.impl;

//import com.github.pagehelper.PageHelper;
//import com.github.pagehelper.PageInfo;
//import com.lea.proj.dao.CostMapper;
//import com.lea.proj.model.Cost;
//import com.lea.proj.model.CostExample;
//import com.lea.proj.model.common.CostConditionVo;
//import com.lea.proj.model.common.Select2Vo;
//import com.lea.proj.service.CostService;
import com.hxkc.dao.KnifeDao;
import com.hxkc.dao.ServiceDao;
import com.hxkc.dao.support.IBaseDao;
import com.hxkc.entity.Knife;
import com.hxkc.entity.ServiceEntity;
import com.hxkc.service.KnifeService;
import com.hxkc.service.SaleingService;
import com.hxkc.service.support.impl.BaseServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

//
@Service
public class SaleingServiceImpl extends BaseServiceImpl<ServiceEntity, String> implements SaleingService {
//https://blog.csdn.net/qq_30401609/article/details/82384766
    @Autowired
    private ServiceDao serviceDao;

    @Override
    public IBaseDao<ServiceEntity, String> getBaseDao() {
        return this.serviceDao;
    }


    @Override
    public void saveOrUpdate(ServiceEntity entity) {
        if(entity!=null) {
            serviceDao.save(entity);
        }
    }

    @Override
    public Page<ServiceEntity> findAllByLike(String searchText, PageRequest pageRequest) {
        if(StringUtils.isBlank(searchText)){
            searchText = "";
        }
        return serviceDao.findAllByNameContaining(searchText, pageRequest);
    }


}
