package com.hxkc.service.impl;


import com.hxkc.dao.BroadCastDao;
import com.hxkc.dao.PatientDao;
import com.hxkc.dao.support.IBaseDao;
import com.hxkc.entity.BroadCast;
import com.hxkc.entity.Patient;
import com.hxkc.service.BroadCastService;
import com.hxkc.service.PatientService;
import com.hxkc.service.support.impl.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

//
@Service
public class PatientServiceImpl extends BaseServiceImpl<Patient, String> implements PatientService {
//https://blog.csdn.net/qq_30401609/article/details/82384766
    @Autowired
    private PatientDao patientDao;

    @Override
    public IBaseDao<Patient, String> getBaseDao() {
        return this.patientDao;
    }


    @Override
    public void saveOrUpdate(Patient entity) {
        if(entity!=null) {
            patientDao.save(entity);
        }
    }






}
