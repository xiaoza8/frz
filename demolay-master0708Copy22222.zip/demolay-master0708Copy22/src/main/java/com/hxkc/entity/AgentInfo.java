package com.hxkc.entity;

import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;

public class AgentInfo implements Serializable {



    private String hospital;

    private String surgery;

    private MultipartFile blFile;

    private static final long serialVersionUID = 1L;

    public String getHospital() {
        return hospital;
    }

    public void setHospital(String hospital) {
        this.hospital = hospital;
    }

    public String getSurgery() {
        return surgery;
    }

    public void setSurgery(String surgery) {
        this.surgery = surgery;
    }

    public MultipartFile getBlFile() {
        return blFile;
    }

    public void setBlFile(MultipartFile blFile) {
        this.blFile = blFile;
    }




}
