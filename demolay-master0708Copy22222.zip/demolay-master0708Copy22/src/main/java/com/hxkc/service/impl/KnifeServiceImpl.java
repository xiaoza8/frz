package com.hxkc.service.impl;

//import com.github.pagehelper.PageHelper;
//import com.github.pagehelper.PageInfo;
//import com.lea.proj.dao.CostMapper;
//import com.lea.proj.model.Cost;
//import com.lea.proj.model.CostExample;
//import com.lea.proj.model.common.CostConditionVo;
//import com.lea.proj.model.common.Select2Vo;
//import com.lea.proj.service.CostService;
import com.hxkc.dao.KnifeDao;
import com.hxkc.dao.support.IBaseDao;
import com.hxkc.entity.Knife;
import com.hxkc.entity.Resource;
import com.hxkc.entity.Role;
import com.hxkc.service.KnifeService;
import com.hxkc.service.support.impl.BaseServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
//
@Service
public class KnifeServiceImpl extends BaseServiceImpl<Knife, String> implements KnifeService {
//https://blog.csdn.net/qq_30401609/article/details/82384766
    @Autowired
    private KnifeDao knifeDao;

    @Override
    public IBaseDao<Knife, String> getBaseDao() {
        return this.knifeDao;
    }

    @Override
    public void importExcel(List<Knife> costList) {
        for (Knife cost : costList) {
            //要添加uuid作为id
            knifeDao.save(cost);
        }
    }

    @Override
    public Page<Knife> findAllByLike(String searchText, PageRequest pageRequest) {
        if(StringUtils.isBlank(searchText)){
            searchText = "";
        }
        return knifeDao.findAllByNameContaining(searchText, pageRequest);
    }


}
