package com.hxkc.dao;

import com.hxkc.dao.support.IBaseDao;
import com.hxkc.entity.Knife;
import com.hxkc.entity.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KnifeDao extends IBaseDao<Knife, String> {



	Page<Knife> findAllByNameContaining(String searchText, Pageable pageable);

	List<Knife> findByName(String name);

}
