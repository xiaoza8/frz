package com.hxkc.dao;

import com.hxkc.dao.support.IBaseDao;
import com.hxkc.entity.BroadCast;
import com.hxkc.entity.ServiceEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BroadCastDao extends IBaseDao<BroadCast, String> {



	//Page<ServiceEntity> findAllByNameContaining(String searchText, Pageable pageable);

	//List<BroadCast> findByName(String name);

	@Query("select * from tb_resource_broadcast u order by create_time desc limit 8")
	List<BroadCast> findByTimeDescLimit8();


}
