package com.hxkc.entity;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.hxkc.entity.support.BaseEntity;

import javax.persistence.*;


@Entity
@Table(name = "tb_resource_knife")
public class Knife extends BaseEntity {

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Id
    @Column(name = "id", nullable = false)
    @Excel(name = "id", orderNum = "0")
    public  String id;

    @Excel(name = "name", orderNum = "1")
    public String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    @Excel(name = "size", orderNum = "2")
    public int size;
}
