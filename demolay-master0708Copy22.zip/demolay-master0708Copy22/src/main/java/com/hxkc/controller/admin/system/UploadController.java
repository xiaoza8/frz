package com.hxkc.controller.admin.system;

import com.hxkc.common.Msg;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.util.ClassUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @Author: jiangkun
 * @Description:
 * @Date: Created in 2019-04-28 16:26
 */
@Controller
public class UploadController {

    private static final String NGINX_ATTACH_PREFIX_URL = "http://localhost/attachments/";
    private static final String NGINX_IMAGES_PREFIX_URL = "http://localhost/images/";
    private static final String NGINX_DOC_ROOT = "C:\\work\\temiam";
    private  final String URL = "http://localhost/";

    //图片base64化后，请参考https://cloud.tencent.com/developer/article/1446283
    @PostMapping("/upload")
    @ResponseBody
    public Msg singleImage(@RequestParam("file") MultipartFile file, HttpServletRequest request) throws FileNotFoundException {  //参数名需与前端文件标签名一样
        //获取项目classes/static的地址
        String path = ClassUtils.getDefaultClassLoader().getResource("static").getPath();
        String fileName = file.getOriginalFilename();  //获取文件名
        //图片访问URI(即除了协议、地址和端口号的URL)
        //String url_path = "imageupload"+File.separator+fileName;
        String url_path = "imageupload";
        System.out.println("图片访问uri："+url_path);
        String savePath = path+File.separator+url_path;  //图片保存路径
        System.out.println("图片保存地址："+savePath);
        File saveFile = new File(savePath);
        if (!saveFile.exists()){
            saveFile.mkdirs();
            //saveFile.
        }
        try {
            uploadFile(file, savePath, fileName);
           // file.transferTo(saveFile);  //将临时存储的文件移动到真实存储路径下
        } catch (Exception e) {
            e.printStackTrace();
            return Msg.fail();

        }
        //返回图片访问地址
        System.out.println("访问URL："+URL+url_path);
       return Msg.success(URL+url_path+File.separator+fileName,fileName);

    }

    //返回图片的base64

    private String getBase64FromImageName(String fileName)
    {

          byte[] buffer=null;
          InputStream in = null;
     // 原文件名称
         //  String filename = file.getOriginalFilename();
        // 读取图片字节数组
        try {
            //获取图片路径
           // Resource resource = new ClassPathResource(URL+url_path+File.separator+fileNam+imageName+".png");
            Resource resource = new ClassPathResource(URL+File.separator+fileName);
            File file = resource.getFile();
            in = new FileInputStream(file.getPath());

            buffer = new byte[in.available()];
            in.read(buffer);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

                // 转换为base64编码格式
        String base64 = new sun.misc.BASE64Encoder().encode(buffer);
        return base64;


        // 对字节数组Base64编码
      //  BASE64Encoder encoder = new BASE64Encoder();
//        // 返回Base64编码过的字节数组字符串
//        return encoder.encode(data);




        //return "";

    }



    //处理文件上传
    @RequestMapping(value = "/upload1", method = RequestMethod.POST)
    @ResponseBody
    public Msg uploadImg(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
        String contentType = file.getContentType();   //图片文件类型
        String fileName = file.getOriginalFilename();  //图片名字
        System.out.println(contentType + "," + fileName);
        //文件存放路径
        String newFilePath = NGINX_DOC_ROOT + (contentType.startsWith("image") ? "images/" : "attachments/");
        try {
            String newFileName = UUID.randomUUID().toString() + fileName.substring(fileName.lastIndexOf('.'));
            uploadFile(file, newFilePath, newFileName);
            return Msg.success(contentType.startsWith("image") ? NGINX_IMAGES_PREFIX_URL + newFileName : NGINX_ATTACH_PREFIX_URL + newFileName, fileName);
        } catch (Exception e) {
            e.printStackTrace();
            return Msg.fail();
        }
    }

    @RequestMapping(value = "/upima", method = RequestMethod.POST)
    @ResponseBody
    public String uploadImg1(@RequestParam Map<String, Object> params, HttpServletRequest request) {
   //${pageContext.request.contextPath}
        try {
            System.out.println("url list is:" + params.get("urlStringList"));
            System.out.println("title is:" + params.get("title"));

        } catch (Exception e) {
            e.printStackTrace();
            return "no ok";
        }

        return "ok";
    }
    private void uploadFile(MultipartFile file, String targetDir, String targetFileName) {
        File dir = new File(targetDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        try (BufferedInputStream bis = new BufferedInputStream(file.getInputStream());
             BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(targetDir + File.separator + targetFileName))) {
            byte[] bytes = new byte[1024];
            int length;
            while ((length = bis.read(bytes)) != -1) {
                bos.write(bytes, 0, length);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
