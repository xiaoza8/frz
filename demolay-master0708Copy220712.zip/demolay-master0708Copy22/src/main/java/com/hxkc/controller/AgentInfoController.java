package com.hxkc.controller;

import com.hxkc.common.JsonResult;
import com.hxkc.common.utils.FileUtil;
import com.hxkc.entity.AgentInfo;
import com.hxkc.entity.Knife;
import com.hxkc.entity.Resource;
import com.hxkc.entity.ServiceEntity;
import com.hxkc.service.KnifeService;
import com.hxkc.service.SaleingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.ui.ModelMap;
import org.springframework.util.ClassUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@RestController
public class AgentInfoController  extends BaseController{


    @Autowired
    private KnifeService knifeService;


    @Autowired
    private SaleingService saleingService;


    @PostMapping(value = "/uploadexcel")
    public String saveAgent(AgentInfo agentInfo) throws Exception {
        if (agentInfo == null) {
            return "agentinfo could not be empty";
        }

        MultipartFile blFile = agentInfo.getBlFile();
        if (!blFile.isEmpty()) {

            List<Knife> knifeList = FileUtil.importExcel(blFile, 0, 1, Knife.class);
            knifeService.importExcel(knifeList);

        }

         return "success";
    }




    @RequestMapping(value = "/batch/upload", method = RequestMethod.POST)
    @ResponseBody
    public String handleFileUpload(HttpServletRequest request) {
        MultipartHttpServletRequest params=((MultipartHttpServletRequest) request);
        List<MultipartFile> files = ((MultipartHttpServletRequest) request)
                .getFiles("file");

        String name=params.getParameter("surgery");
        System.out.println("name:"+name);
        String id=params.getParameter("hospital");
        System.out.println("id:"+id);
        MultipartFile bFile =files.get(0); ;
        if (!bFile.isEmpty()) {

            List<Knife> knifeList = FileUtil.importExcel(bFile, 0, 1, Knife.class);
            knifeService.importExcel(knifeList);

        }


//        BufferedOutputStream stream = null;
//        for (int i = 0; i < files.size(); ++i) {
//            file = files.get(i);
//            if (!file.isEmpty()) {
//                try {
//                    byte[] bytes = file.getBytes();
//                    stream = new BufferedOutputStream(new FileOutputStream(
//                            new File(file.getOriginalFilename())));
//                    stream.write(bytes);
//                    stream.close();
//                } catch (Exception e) {
//                    stream = null;
//                    return "You failed to upload " + i + " => "
//                            + e.getMessage();
//                }
//            } else {
//                return "You failed to upload " + i
//                        + " because the file was empty.";
//            }
//        }
        return "upload successful";
    }



    @RequestMapping("/knife/getDataByPage")
    @ResponseBody
    public Page<Knife> listknife(
            @RequestParam(value="searchText",required=false) String searchText
    ) {
//		SimpleSpecificationBuilder<Resource> builder = new SimpleSpecificationBuilder<Resource>();
//		String searchText = request.getParameter("searchText");
//		if(StringUtils.isNotBlank(searchText)){
//			builder.add("name", Operator.likeAll.name(), searchText);
//		}
        Page<Knife> page = knifeService.findAllByLike(searchText,getPageRequest());
        return page;
    }

  //如何序列化
    @RequestMapping(value= {"/submitService"}, method = RequestMethod.POST)
    @ResponseBody
    public JsonResult edit(ServiceEntity resource, ModelMap map){
        try {
            String id=UUID.randomUUID().toString();
            resource.setId(id);
            resource.setCreateTime(new Date());
            saleingService.saveOrUpdate(resource);
        } catch (Exception e) {
            return JsonResult.failure(e.getMessage());
        }
        return JsonResult.success();
    }

}

