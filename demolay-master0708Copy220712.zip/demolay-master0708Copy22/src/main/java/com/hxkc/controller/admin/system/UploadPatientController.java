package com.hxkc.controller.admin.system;

import com.hxkc.common.Msg;
import com.hxkc.entity.BroadCast;
import com.hxkc.entity.ImageJson;
import com.hxkc.entity.Patient;
import com.hxkc.service.BroadCastService;
import com.hxkc.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.ClassUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * @Author: lmq
 *
 */
@Controller
public class UploadPatientController {

    private static final String NGINX_ATTACH_PREFIX_URL = "http://localhost/attachments/";
    private static final String NGINX_IMAGES_PREFIX_URL = "http://localhost/images/";
    private static final String NGINX_DOC_ROOT = "C:\\work\\temiam";
    private  final String URL = "http://localhost/";


    @Autowired
    private PatientService patientService;


    //图片base64化后，请参考https://cloud.tencent.com/developer/article/1446283
    @PostMapping("/uploadpatient")
    @ResponseBody
    public Msg singleImage(@RequestParam("file") MultipartFile file, HttpServletRequest request) throws FileNotFoundException {  //参数名需与前端文件标签名一样
        //获取项目classes/static的地址
        String contentType = file.getContentType();   //图片文件类型
        String fileName = file.getOriginalFilename();  //图片名字
        System.out.println(contentType + "," + fileName);
        String tureName=fileName.substring(0,fileName.lastIndexOf('.'));
        //文件存放路径
        String path = ClassUtils.getDefaultClassLoader().getResource("static").getPath();
       // String fileName = file.getOriginalFilename();  //获取文件名
       // String fileName=UUID.randomUUID().toString();  //使用uuid替换真正的文件名
        String newFileName = tureName+"+"+UUID.randomUUID().toString() + fileName.substring(fileName.lastIndexOf('.'));
        //图片访问URI(即除了协议、地址和端口号的URL)
        //String url_path = "imageupload"+File.separator+fileName;
        String url_path = "patientupload";
      //  System.out.println("图片访问uri："+url_path);
        String savePath = path+File.separator+url_path;  //图片保存路径
        System.out.println("patient crf 保存地址："+savePath);
        File saveFile = new File(savePath);
        if (!saveFile.exists()){
            saveFile.mkdirs();
            //saveFile.
        }
        try {
            uploadFile(file, savePath, newFileName);
           // file.transferTo(saveFile);  //将临时存储的文件移动到真实存储路径下
        } catch (Exception e) {
            e.printStackTrace();
            return Msg.fail();

        }
        //返回crf访问地址
        System.out.println("访问URL："+URL+url_path);
       return Msg.success(newFileName,newFileName);

    }

    //返回图片的base64

    private String getBase64FromImageName(String fileName)
    {

        String path = ClassUtils.getDefaultClassLoader().getResource("static").getPath();
        // String fileName = file.getOriginalFilename();  //获取文件名

        //图片访问URI(即除了协议、地址和端口号的URL)
        //String url_path = "imageupload"+File.separator+fileName;
        String url_path = "uploadpatient";

        String savePath = path+File.separator+url_path;

          byte[] buffer=null;
          InputStream in = null;
     // 原文件名称
         //  String filename = file.getOriginalFilename();
        // 读取图片字节数组
        try {
            //获取图片路径
           // Resource resource = new ClassPathResource(URL+url_path+File.separator+fileNam+imageName+".png");
           // Resource resource = new ClassPathResource(savePath+File.separator+fileName);
           // File file = resource.getFile();
            File file=new File(savePath+File.separator+fileName);
            in = new FileInputStream(file);

            buffer = new byte[in.available()];
            in.read(buffer);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

                // 转换为base64编码格式
        String base64 = new BASE64Encoder().encode(buffer);
        return base64;


        // 对字节数组Base64编码
      //  BASE64Encoder encoder = new BASE64Encoder();
//        // 返回Base64编码过的字节数组字符串
//        return encoder.encode(data);




        //return "";

    }



    //处理文件上传
    @RequestMapping(value = "/upload11", method = RequestMethod.POST)
    @ResponseBody
    public Msg uploadImg(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
        String contentType = file.getContentType();   //图片文件类型
        String fileName = file.getOriginalFilename();  //图片名字
        System.out.println(contentType + "," + fileName);
        //文件存放路径
        String newFilePath = NGINX_DOC_ROOT + (contentType.startsWith("image") ? "images/" : "attachments/");
        try {
            String newFileName = UUID.randomUUID().toString() + fileName.substring(fileName.lastIndexOf('.'));
            uploadFile(file, newFilePath, newFileName);
            return Msg.success(contentType.startsWith("image") ? NGINX_IMAGES_PREFIX_URL + newFileName : NGINX_ATTACH_PREFIX_URL + newFileName, fileName);
        } catch (Exception e) {
            e.printStackTrace();
            return Msg.fail();
        }
    }

    @RequestMapping(value = "/savepatient", method = RequestMethod.POST)
    @ResponseBody
    public String uploadpatient(Patient patient, HttpServletRequest request) {
       // public String uploadImg1(@RequestParam Map<String, Object> params, HttpServletRequest request) {
   //${pageContext.request.contextPath}
        try {
            //病人crf记录表
            String id=UUID.randomUUID().toString();
            patient.setId(id);
              patient.setCreateTime(new Date());
              patientService.saveOrUpdate(patient);

        } catch (Exception e) {
            e.printStackTrace();
            return "no ok";
        }

        return "ok";
    }
    private void uploadFile(MultipartFile file, String targetDir, String targetFileName) {
        File dir = new File(targetDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        try (BufferedInputStream bis = new BufferedInputStream(file.getInputStream());
             BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(targetDir + File.separator + targetFileName))) {
            byte[] bytes = new byte[1024];
            int length;
            while ((length = bis.read(bytes)) != -1) {
                bos.write(bytes, 0, length);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//    @RequestMapping(value = "/getLastestImg", method = RequestMethod.GET)
//    @ResponseBody
//    public List<ImageJson> getLastestImg( HttpServletRequest request) {
//        //${pageContext.request.contextPath}
//
//
//        List<ImageJson>imageJsonList =new ArrayList<>();
//        List<BroadCast>list=broadCastService.findByTimeDescLimit8();
//
//        if(list!=null)
//        {
//            if(list.size()>0)
//            {
//                //以文件名获取图片文件，转base64返回
//                for(int i=0;i<list.size();i++)
//                {
//                    ImageJson imageJson=new ImageJson();
//                    BroadCast broadCast=list.get(i);
//
//                    String filename=broadCast.getUrlList().replace(";","");
//
//                    imageJson.setBase64Str(getBase64FromImageName(filename));
//                    imageJson.setTitle(broadCast.getTitle());
//
//                    imageJsonList.add(imageJson);
//                }
//
//            }
//
//
//        }
//
//
//
//
//        return imageJsonList;
//    }



}
