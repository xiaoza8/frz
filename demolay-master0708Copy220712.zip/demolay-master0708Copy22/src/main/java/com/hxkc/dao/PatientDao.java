package com.hxkc.dao;

import com.hxkc.dao.support.IBaseDao;
import com.hxkc.entity.Patient;
import com.hxkc.entity.ServiceEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PatientDao extends IBaseDao<Patient, String> {



	//Page<ServiceEntity> findAllByNameContaining(String searchText, Pageable pageable);

	//List<ServiceEntity> findByName(String name);

}
