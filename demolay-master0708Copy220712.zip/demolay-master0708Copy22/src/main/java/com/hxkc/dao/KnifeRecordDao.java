package com.hxkc.dao;

import com.hxkc.dao.support.IBaseDao;
import com.hxkc.entity.KnifeRecord;
import com.hxkc.entity.Patient;
import org.springframework.stereotype.Repository;

@Repository
public interface KnifeRecordDao extends IBaseDao<KnifeRecord, String> {



	//Page<ServiceEntity> findAllByNameContaining(String searchText, Pageable pageable);

	//List<ServiceEntity> findByName(String name);

}
