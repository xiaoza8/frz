package com.hxkc.service.impl;


import com.hxkc.dao.KnifeRecordDao;
import com.hxkc.dao.PatientDao;
import com.hxkc.dao.support.IBaseDao;
import com.hxkc.entity.KnifeRecord;
import com.hxkc.entity.Patient;
import com.hxkc.service.KnifeRecordService;
import com.hxkc.service.PatientService;
import com.hxkc.service.support.impl.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//
@Service
public class KnifeRecordServiceImpl extends BaseServiceImpl<KnifeRecord, String> implements KnifeRecordService {
//https://blog.csdn.net/qq_30401609/article/details/82384766
    @Autowired
    private KnifeRecordDao knifeRecordDao;

    @Override
    public IBaseDao<KnifeRecord, String> getBaseDao() {
        return this.knifeRecordDao;
    }


    @Override
    public void saveOrUpdate(KnifeRecord entity) {
        if(entity!=null) {
            knifeRecordDao.save(entity);
        }
    }






}
