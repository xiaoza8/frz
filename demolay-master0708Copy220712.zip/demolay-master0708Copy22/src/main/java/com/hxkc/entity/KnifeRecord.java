package com.hxkc.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.hxkc.entity.support.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;


@Entity
@Table(name = "tb_resource_kniferecord")
public class KnifeRecord extends BaseEntity {

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }



    @Id
    @Column(name = "id", nullable = false)

    public  String id;

    public String getHospital() {
        return hospital;
    }

    public void setHospital(String hospital) {
        this.hospital = hospital;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTypeofoperation() {
        return typeofoperation;
    }

    public String getKnifename() {
        return knifename;
    }

    public void setKnifename(String knifename) {
        this.knifename = knifename;
    }

    public void setTypeofoperation(String typeofoperation) {
        this.typeofoperation = typeofoperation;
    }


    private  String hospital;
    private String location;
    private String typeofoperation;
    private String knifename;

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 创建时间
     */
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

}
