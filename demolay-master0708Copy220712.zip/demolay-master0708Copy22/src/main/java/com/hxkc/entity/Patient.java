package com.hxkc.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.hxkc.entity.support.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;


@Entity
@Table(name = "tb_resource_patient")
public class Patient extends BaseEntity {

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }



    @Id
    @Column(name = "id", nullable = false)

    public  String id;

    public String getHospital() {
        return hospital;
    }

    public void setHospital(String hospital) {
        this.hospital = hospital;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTypeofoperation() {
        return typeofoperation;
    }

    public void setTypeofoperation(String typeofoperation) {
        this.typeofoperation = typeofoperation;
    }

    public String getPatientname() {
        return patientname;
    }

    public void setPatientname(String patientname) {
        this.patientname = patientname;
    }

    private  String hospital;
    private String location;
    private String typeofoperation;
    private String patientname;

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 创建时间
     */
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

}
