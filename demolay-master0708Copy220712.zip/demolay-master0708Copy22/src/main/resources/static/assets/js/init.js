// 导航vm
var navbarVm = new Vue({
    el: '#navbar',
    data: {
        items: [
            {
                title: '手术刀列表',
                url: '/payment/'
            }
//            {
//                title: '退款列表',
//                url: '/refund/'
//            }
//            {
//                title: '费用列表',
//                url: '/cost/'
//            },
//            {
//                title: '结算列表',
//                url: '/settlement/'
//            },
        ],
        isActive: 0
    },
    methods: {
        changeList: function (index, url) {
            this.isActive == index;
            initBootstrapTable(url, index + 1);
        }
    },
})

// 初始化bootstrapTable
$('#tb').bootstrapTable({
    //url: "/payment/getDataByPage",
      url: "/knife/getDataByPage",
   // method: "get",
      method: "POST",
 //必须设置，不然request.getParameter获取不到请求参数
 contentType: "application/x-www-form-urlencoded",
  //获取数据的Servlet地址
    striped: true,                      //是否显示行间隔色
    cache: false,                       //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
    pagination: true,                   //是否显示分页（*）
    sortable: false,                    //是否启用排序
    pageNumber: 1,
    pageSize: 10,
    pageList: [5, 10, 15, 20, 25],
    columns: paymentColumns,
    sidePagination: "server",
    //dataField: "data",
    //是否启用查询
     search: true,
     //是否启用详细信息视图
    detailView:true,
     //detailFormatter:detailFormatter,
    showColumns: true,
    toolbar: '#toolbar',
     queryParamsType: "undefined",
//    queryParams: function (params) {
//        return {
//            pageNum: params.offset / params.limit + 1,
//            pageSize: params.limit
//        };
//    },
    responseHandler: function (result) {
        return {
          //  total: result.total, //总页数,前面的key必须为"total"
           // data: result.list //行数据，前面的key要与之前设置的dataField的值一致.
            "rows": result.content,
          "total": result.totalElements
        };
    },
});

// 获取下拉框数据
var getSelect2Data = function(url) {
    var result = [];
    $.ajax({
        type: "GET",
        url: url,
        async: false,
        cache: false,
        success: function(res) {
            result = res;
        }
    });
    return result;
}

// 初始化select2
$("#area").select2({
    data: getSelect2Data('/payment/getAllOrderId'),
    data: getSelect2Data('/payment/getAllOrderId'),
    placeholder: '--请选择--',
    allowClear: true
});

// 初始化日期控件
jeDate({
    dateCell: "#beginTime1",
    isTime: true,
    format: "YYYY-MM-DD hh:mm:ss", //控制是否显示小时
});
jeDate({
    dateCell: "#endTime1",
    isTime: true,
    format: "YYYY-MM-DD hh:mm:ss", //控制是否显示小时
});

jeDate({
    dateCell: "#startTime2",
    isTime: true,
    format: "YYYY-MM-DD hh:mm:ss", //控制是否显示小时
});
jeDate({
    dateCell: "#endTime2",
    isTime: true,
    format: "YYYY-MM-DD hh:mm:ss", //控制是否显示小时
});
$('#finishedStart').hide();
$('#finishedEnd').hide();