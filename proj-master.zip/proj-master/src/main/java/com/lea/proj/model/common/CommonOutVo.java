package com.lea.proj.model.common;

public class CommonOutVo {

    // 0:成功，1:失败
    private String status;

    // 信息
    private String msg;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
